<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->library('session');
		$this->load->library('form_validation');
    }

	public function login()
	{
		if($this->session->userdata('email'))
		{
			redirect('home');
		} else {
			$this->load->view('v_login');
		} 

	}

    // Method untuk Memproses Data Pada saat Input Login
	public function proses_login()
	{	
		// Validasi Username
		$this->form_validation->set_rules('email','Email','trim|required');
		$this->form_validation->set_rules('password','Password','trim|required');
		if($this->form_validation->run() == false) {
			$this->load->view('v_login'); // load view home.php
		} else {
			// Validasi Berhasil
			$this->_login();
		}
	}
	// Method untuk Login
	private function _login()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$user = $this->db->get_where('user', ['email' => $email])->row_array();

		
			// Cek Password
			if (password_verify($password, $user['password'])){
					$data = [
						'email' => $user['email']
					];
					$this->session->set_userdata($data);
					echo 
					"
					<script>
					alert('Selamat Datang User!');window.location='../home';
					</script>
					";
					
				} else {
					echo
					"
					<script>
					alert('Nik Atau Password Salah!!');window.location='';
					</script>
					";
				}
			}



	public function registrasi()
	{
		$this->load->view('v_registrasi');
	}

	//Method Registrasi
	// Method Untuk Registrasi
	public function proses_registrasi()
	{	
		// Validasi Nik
		$this->form_validation->set_rules('email','Email','required|trim|is_unique[user.email]',[
			'is_unique' => 'Email Ini Sudah Digunakan'
		]);
		// Validasi Username
		$this->form_validation->set_rules('username','UserName','required|trim');
		// Validasi Password
		$this->form_validation->set_rules('password','Password','required|trim');
		


		if($this->form_validation->run() == false) {
			$this->load->view('v_registrasi'); // load view home.php
		} else {
			$data = [
				'email' => htmlspecialchars($this->input->post('email', true)),
				'username' => htmlspecialchars($this->input->post('username', true)),
				'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
				'email' => $this->input->post('email')
			];

			$this->db->insert('user', $data);
			$this->session->set_flashdata('message','Selamat Akun anda Telah Terdaftar');
			redirect('auth/login');
		}
	}
    // Method Log out
	public function logout()
	{
		$this->session->unset_userdata('email');
		echo 
		"
		<script>
		alert('Anda Telah Logout!');window.location='../home';
		</script>
		";
	}
}
