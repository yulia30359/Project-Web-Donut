<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct() {
        parent::__construct();

    }

	public function index()
	{
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        
        $data['news'] = $this->get_google_news();
        
        
		$this->load->view('v_home', $data);
	}
	private function get_google_news() {
        $rss_feed_url = 'https://news.google.com/rss?hl=en-ID&gl=ID&ceid=ID:id&q=donut';
        $rss_feed = simplexml_load_file($rss_feed_url);

        $news = [];

        foreach ($rss_feed->channel->item as $item) {
            $news[] = [
                'title' => (string)$item->title,
                'link' => (string)$item->link,
                'description' => (string)$item->description,
                'pubDate' => $item->pubDate,
            ];
        }

        return $news;
    }
}

?>
