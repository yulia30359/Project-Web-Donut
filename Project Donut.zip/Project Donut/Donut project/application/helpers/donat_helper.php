<?php

function is_logged_in(){
    
    $donat = get_instance();
    if(!$donat->session->userdata('email')) {
        redirect('auth');
    }
}

?>