<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Website</title>
    <link rel="stylesheet" href="<?= base_url('asset/style.css');?>">
    <link rel="stylesheet" href="<?= base_url('asset/all.min.css');?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <section id="Home">
        <nav>
            <div class="logo">
                <img src="<?= base_url('asset/image/donat.png');?> ">
            </div>

            <ul>
                <li><a href="#Home">Home</a></li>
                <li><a href="#About">About</a></li>
                <li><a href="#Menu">Menu</a></li>
                <li><a href="#Gallery">Gallery</a></li>
                <li><a href="#Review">Review</a></li>
                <?php if($this->session->userdata("email")) { ?>
                <li><a href="<?= base_url('auth/logout');?>">Logout</a></li>
                <?php } else { ?>
                <li><a href="#Order">Order</a></li>
                <?php } ?>
            </ul>

            <div class="icon">
                <i class="fa-solid fa-magnifying-glass"></i>
                <i class="fa-solid fa-heart"></i>
                <i class="fa-solid fa-cart-shopping"></i>
                <?php if($this->session->userdata("email")) { ?>
                <a href="<?= base_url('auth/login');?>"><i class="fa-solid fa-user"><?= $user['username']; ?></i></a>
                <?php } else { ?>
                <a href="<?= base_url('auth/login');?>"><i class="fa-solid fa-user"> Login </i></a>
                <?php } ?>
            </div>

        </nav>

        <div class="main">

            <div class="men_text">
                <h1>Get Fresh<span>Donut</span><br>From The Oven</h1>
            </div>

            <div class="main_image">
                <img src="<?= base_url('asset/image/makanan.png'); ?>">
            </div>

        </div>

        <p>
            Glam Donut, a haven for connoisseurs of delightful pastries, invites you to indulge in the epitome of sweetness and elegance. 
            Our artisanal donuts are meticulously crafted, blending enticing flavors and artistic presentation. From classic favorites to 
            bespoke creations, each bite is a journey into a world of exquisite taste. Celebrate life's special moments with our specially curated
            donut selections, perfect for birthdays, weddings, or any occasion that deserves a touch of sweetness. Visit Glam Donut today and experience 
            the unparalleled pleasure of savoring donuts that are not just treats but culinary masterpieces.
        </p>

        <div class="main_btn">
            <a href="#">Order Now</a>
            <i class="fa-solid fa-angle-right"></i>
        </div>

    </section>



    <!--About-->

    <div class="about" id="About">
        <div class="about_main">

            <div class="image">
                <img src="<?= base_url('asset/image/Decoration.png'); ?>">
            </div>

            <div class="about_text">
                <h1><span>About</span>Us</h1>
                <h3>Why Choose us?</h3>
                <p>
                    Choose Glam Donut for an unparalleled culinary experience that 
                    transcends the ordinary. Our commitment to excellence begins with 
                    the finest, freshest ingredients, ensuring each bite is a moment 
                    of pure indulgence. Crafted with precision and passion, our artisanal 
                    donuts stand as a testament to our dedication to quality and creativity.
                </p>
            </div>

        </div>

        <a href="#" class="about_btn">Order Now</a>

    </div>



    <!--Menu-->

    <div class="menu" id="Menu">
        <h1>Our<span>Menu</span></h1>

        <div class="menu_box">
            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/download.png'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Caramel</h2>
                    <p>
                        Donut With Milk cream, caramel paste and peanut springkle
                    </p>
                    <h3>$5.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 
            
            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/squish.png'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Flower</h2>
                    <p>
                        Donut with Milk cream and Crispy Rice
                    </p>
                    <h3>$5.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/oreo.png'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Oreo</h2>
                    <p>
                        Donut with Vanila cream, Oreo and chocolate paste
                    </p>
                    <h3>$5.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/chocolate.png'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Milkshake</h2>
                    <p>
                        Milk with Blend chocolate
                    </p>
                    <h3>$20.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/red velvet.png'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Red Velvet</h2>
                    <p>
                        Donut with vanila cream and red velvet sparkle
                    </p>
                    <h3>$20.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/glaze.png'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Glaze</h2>
                    <p>
                        Donut with melted sugar
                    </p>
                    <h3>$20.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/cookies.png'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Cookies</h2>
                    <p>
                        Cookies with chochochip
                    </p>
                    <h3>$20.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/donut2.jpeg'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Choco Bubble</h2>
                    <p>
                        Donut with Bubble gum cream and chochochip
                    </p>
                    <h3>$20.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/gelato.jpeg'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Gelato</h2>
                    <p>
                        Gelato With fruity variant flavors
                    </p>
                    <h3>$20.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/blackforest.jpeg'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>BlackForest</h2>
                    <p>
                        Donut with BlackForest falvor and cherry
                    </p>
                    <h3>$20.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/berry.png'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Berry</h2>
                    <p>
                        Donut with Berry jam and chesee
                    </p>
                    <h3>$20.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="<?= base_url('asset/image/tiramisu.jpeg'); ?>">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Tiramisu</h2>
                    <p>
                        Donut With tiramisu flavors
                    </p>
                    <h3>$20.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="#" class="menu_btn">Order Now</a>
                </div>

            </div> 
            
        </div>

    </div>




    <!--Gallary-->

    <div class="gallary" id="Gallery">
        <h1>Our<span>Gallary</span></h1>

        <div class="gallary_image_box">
            <div class="gallary_image">
                <img src="<?= base_url('asset/image/Apple (1).jpeg'); ?>">

                <h3>Donut</h3>
                <p>
                    
                </p>
                <a href="#" class="gallary_btn">Order Now</a>
            </div>

            <div class="gallary_image">
                <img src="<?= base_url('asset/image/ice cream.jpeg'); ?>">

                <h3>Food</h3>
                <p>
                    
                </p>
                <a href="#" class="gallary_btn">Order Now</a>
            </div>

            <div class="gallary_image">
                <img src="<?= base_url('asset/image/Donut4.jpeg'); ?>">

                <h3>Food</h3>
                <p>
                    
                </p>
                <a href="#" class="gallary_btn">Order Now</a>
            </div>

            <div class="gallary_image">
                <img src="<?= base_url('asset/image/vinchricci.jpeg'); ?>">

                <h3>Cake</h3>
                <p>
                    
                </p>
                <a href="#" class="gallary_btn">Order Now</a>
            </div>

            <div class="gallary_image">
                <img src="<?= base_url('asset/image/download3.jpeg'); ?>">

                <h3>Snacks</h3>
                <p>
                   
                </p>
                <a href="#" class="gallary_btn">Order Now</a>
            </div>

            <div class="gallary_image">
                <img src="<?= base_url('asset/image/Easy.jpeg'); ?>">

                <h3>Drink</h3>
                <p>
                   
                </p>
                <a href="#" class="gallary_btn">Order Now</a>
            </div>

        </div>

    </div>




    <!--Review-->

    <div class="review" id="Review">
        <h1>Customer<span>Review</span></h1>

        <div class="review_box">
            <div class="review_card">

                <div class="review_profile">
                    <img src="<?= base_url('/asset/image/review_1.png'); ?>">
                </div>

                <div class="review_text">
                    <h2 class="name">Clarissa</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                       The Taste of all food and drinks on this bramd is so tasty and delicious 
                       especially the donut tastes very balanced and suits my mouth, and it's not 
                       too sweet so I'm not afraid of getting diabetes if I eat it too often 
                    </p>

                </div>

            </div>

            <div class="review_card">

                <div class="review_profile">
                    <img src="<?= base_url('/asset/image/review_2.png'); ?>">
                </div>

                <div class="review_text">
                    <h2 class="name">John Deo</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                    In my opinion, the food from Glam Donut 
                    is very pleasing to the taste buds and the level of 
                    sweetness is just right, so the donuts here are very delicious.
                    </p>

                </div>

            </div>

            <div class="review_card">

                <div class="review_profile">
                    <img src="<?= base_url('/asset/image/review_3.png'); ?>">
                </div>

                <div class="review_text">
                    <h2 class="name">Mariska Ken</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                    In my opinion, the donuts here are very delicious 
                    more than other brands because the composition is very suitable
                    , starting from the cooking method, it is also very perfect when I see it in person.
                    </p>

                </div>

            </div>

            <div class="review_card">

                <div class="review_profile">
                    <img src="<?= base_url('/asset/image/review_4.png'); ?>">
                </div>

                <div class="review_text">
                    <h2 class="name">John Wick</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                    In my personal opinion, when I tried the food
                     and drink there was a very distinctive taste 
                     that other brands don't have, so it made the food very delicious.
                    </p>

                </div>

            </div>

        </div>

    </div>

    <!--Order-->

    <div class="order" id="Order">
        <h1><span>Order</span>Now</h1>

        <div class="order_main">

            <div class="order_image">
                <img src="<?= base_url('/asset/image/order_image.png'); ?>">
            </div>

            <form action="#">

                <div class="input">
                    <p>Name</p>
                    <input type="text" placeholder="you name">
                </div>

                <div class="input">
                    <p>Email</p>
                    <input type="email" placeholder="you email">
                </div>

                <div class="input">
                    <p>Number</p>
                    <input placeholder="you number">
                </div>

                <div class="input">
                    <p>How Much</p>
                    <input type="number" placeholder="how many order">
                </div>

                <div class="input">
                    <p>You Order</p>
                    <input placeholder="food name">
                </div>

                <div class="input">
                    <p>Address</p>
                    <input placeholder="you Address">
                </div>

                <a href="#" class="order_btn">Order Now</a>

            </form>

        </div>

    </div>



    <!--Team-->

    <div class="team">
        <h1>Our<span>Team</span></h1>

        <div class="team_box">
            <div class="profile">
                <img src="<?= base_url('/asset/image/chef1.png'); ?>">

                <div class="info">
                    <h2 class="name">Chef</h2>
                    <p class="bio">5 star headmaster chef</p>

                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

            <div class="profile">
                <img src="<?= base_url('/asset/image/chef2.png'); ?>">

                <div class="info">
                    <h2 class="name">Chef</h2>
                    <p class="bio">Michelin sous chef.</p>

                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

            <div class="profile">
                <img src="<?= base_url('/asset/image/chef3.jpg'); ?>">


                <div class="info">
                    <h2 class="name">Chef</h2>
                    <p class="bio">5 star hotel Pastry chef</p>

                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

            <div class="profile">
                <img src="<?= base_url('/asset/image/chef4.jpg'); ?>">

                <div class="info">
                    <h2 class="name">Chef</h2>
                    <p class="bio">Michelin star Pastry chef</p>

                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

        </div>

    </div>

    <?php if($this->session->userdata("email")) { ?>
    <!-- Content -->
		<div class="content" style="padding: 50px;">
		    
		    <h1 style="padding:10px;text-align: center;">Our<span>News</span></h1>
			
			<div class="cards">

				<table border="1" style="width: 100%;">
					<th>Judul</th>
					<th>Deskripsi</th>
					<th>Tanggal</th>
					<tbody>
					
						<?php foreach ($news as $data): ?>
						<tr>
							<td><a href="<?= $data['link']; ?>"><?= $data['title']; ?></a></td>
							<td><?= $data['description']; ?></td>
							<td><?= date('d F Y', strtotime($data['pubDate'])) ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>	
				</table>	
			</div>
			
		</div>
    <?php } else { ?>
        <!-- Kosong -->
    <?php } ?>

    <div id="map" style="height: 400px;"></div>


    <!--Footer-->

    <footer>
        <div class="footer_main">

            <div class="footer_tag">
                <h2>Location</h2>
                <p>Sri Lanka</p>
                <p>USA</p>
                <p>India</p>
                <p>Japan</p>
                <p>Italy</p>
            </div>

            <div class="footer_tag">
                <h2>Quick Link</h2>
                <p>Home</p>
                <p>About</p>
                <p>Menu</p>
                <p>Gallary</p>
                <p>Order</p>
            </div>

            <div class="footer_tag">
                <h2>Contact</h2>
                <p>+94 12 3456 789</p>
                <p>+94 25 5568456</p>
                <p>johndeo123@gmail.com</p>
                <p>foodshop123@gmail.com</p>
            </div>

            <div class="footer_tag">
                <h2>Our Service</h2>
                <p>Fast Delivery</p>
                <p>Easy Payments</p>
                <p>24 x 7 Service</p>
            </div>

            <div class="footer_tag">
                <h2>Follows</h2>
                <i class="fa-brands fa-facebook-f"></i>
                <i class="fa-brands fa-twitter"></i>
                <i class="fa-brands fa-instagram"></i>
                <i class="fa-brands fa-linkedin-in"></i>
            </div>

        </div>



    </footer>
</body>
</html>