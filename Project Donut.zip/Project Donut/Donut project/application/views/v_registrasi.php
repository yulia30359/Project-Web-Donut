<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <style type="text/css">
        form{
            margin: 250px auto;
            padding: 10px;
            background-color: #f4f4f4;
            width: 400px;
            height: 500px;
            border-radius: 10px;
        }
        img{
            width: 150px;
            text-align: center;
        }
        input[type=text], input[type=password], input[type=email] {
            margin: 5px auto;
            width: 100%;
            padding: 10px;
        }
            input[type=submit] {
            margin: 5px auto;
            float: right;
            padding: 5px;
            width: 90px;
            border: 1px solid #fff;
            background-color: bisque;
            color: #fff;
            background: red;
            cursor: pointer;
        }
    </style>
</head>
<body>
    
    <form action="<?= base_url('auth/proses_registrasi') ?>" method="post">
        <img src="<?= base_url('asset/image/donat.png') ?>" alt="">
        <h2>Registrasi</h2>
        <label>Username</label>
        <input type="text" name="username">
        <label>Email</label>
        <input type="email" name="email">
        <label>Password</label>
        <input type="password" name="password">
        <input type="submit" name="submit" value="Registrasi" />   

        Jika Anda Sudah Punya Akun <a href="<?= base_url('auth/login'); ?>">Login</a>
    </form>

</body>
</html>